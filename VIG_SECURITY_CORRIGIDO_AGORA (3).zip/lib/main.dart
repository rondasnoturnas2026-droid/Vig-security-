import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

const yellow = Color(0xFFE1B82F);
const darkBg = Color(0xFF101010);
const card = Color(0xFF1E1E1E);

Future<Database> openVigDb() async {
  final p = await getDatabasesPath();
  return openDatabase(join(p, 'vig_security.db'), version: 1, onCreate: (db, v) async {
    await db.execute('CREATE TABLE moradores(id INTEGER PRIMARY KEY AUTOINCREMENT,nome TEXT NOT NULL,endereco TEXT NOT NULL,bairro TEXT,dia INTEGER,valor REAL,formaPagamento TEXT)');
    await db.execute('CREATE TABLE faturas(id INTEGER PRIMARY KEY AUTOINCREMENT,moradorId INTEGER NOT NULL,valor REAL NOT NULL,vencimento TEXT NOT NULL,formaPagamento TEXT,status TEXT,retorno TEXT)');
  });
}

class Morador {
  int? id; String nome,endereco,bairro,formaPagamento; int dia; double valor;
  Morador({this.id,required this.nome,required this.endereco,required this.bairro,required this.dia,required this.valor,required this.formaPagamento});
  Map<String,Object?> map()=>{'id':id,'nome':nome,'endereco':endereco,'bairro':bairro,'dia':dia,'valor':valor,'formaPagamento':formaPagamento};
  factory Morador.from(Map<String,Object?> m)=>Morador(id:m['id'] as int?,nome:m['nome'] as String,endereco:m['endereco'] as String,bairro:(m['bairro'] as String?)??'',dia:(m['dia'] as int?)??1,valor:(m['valor'] as num?)?.toDouble()??0,formaPagamento:(m['formaPagamento'] as String?)??'Pix');
}

class Fatura {
  int id,moradorId; double valor; String vencimento,formaPagamento,status,retorno;
  Fatura({required this.id,required this.moradorId,required this.valor,required this.vencimento,required this.formaPagamento,required this.status,required this.retorno});
  factory Fatura.from(Map<String,Object?> m)=>Fatura(id:m['id'] as int,moradorId:m['moradorId'] as int,valor:(m['valor'] as num).toDouble(),vencimento:m['vencimento'] as String,formaPagamento:(m['formaPagamento'] as String?)??'',status:(m['status'] as String?)??'PENDENTE',retorno:(m['retorno'] as String?)??'');
}

class DB {
  static Future<Database> get db=>openVigDb();
  static Future<List<Morador>> moradores() async { final d=await db; return (await d.query('moradores',orderBy:'nome COLLATE NOCASE')).map(Morador.from).toList(); }
  static Future<int> saveMorador(Morador m) async { final d=await db; return m.id==null?d.insert('moradores',m.map()):d.update('moradores',m.map(),where:'id=?',whereArgs:[m.id]); }
  static Future<void> deleteMorador(int id) async { final d=await db; await d.delete('faturas',where:'moradorId=?',whereArgs:[id]); await d.delete('moradores',where:'id=?',whereArgs:[id]); }
  static Future<List<Fatura>> faturas() async { final d=await db; return (await d.query('faturas',orderBy:'id DESC')).map(Fatura.from).toList(); }
  static Future<void> createFatura(int m,double valor,String venc,String forma) async { final d=await db; await d.insert('faturas',{'moradorId':m,'valor':valor,'vencimento':venc,'formaPagamento':forma,'status':'PENDENTE','retorno':''}); }
  static Future<void> updateFatura(int id,Map<String,Object?> x) async { final d=await db; await d.update('faturas',x,where:'id=?',whereArgs:[id]); }
  static Future<void> deleteFatura(int id) async { final d=await db; await d.delete('faturas',where:'id=?',whereArgs:[id]); }
}


Future<void> gerarReciboPdf(BuildContext context, Fatura f, String nomeMorador) async {
  if (f.status != 'RECEBIDO') {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('O recibo só pode ser gerado para uma fatura RECEBIDA.')),
    );
    return;
  }

  final doc = pw.Document();
  final dataPagamento = DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now());

  doc.addPage(
    pw.Page(
      build: (pw.Context ctx) => pw.Padding(
        padding: const pw.EdgeInsets.all(28),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Center(
              child: pw.Text(
                'VIG SECURITY',
                style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold),
              ),
            ),
            pw.SizedBox(height: 8),
            pw.Center(child: pw.Text('RECIBO DE PAGAMENTO', style: pw.TextStyle(fontSize: 15))),
            pw.Divider(),
            pw.SizedBox(height: 12),
            pw.Text('Recebemos de: $nomeMorador', style: pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 8),
            pw.Text('Valor: R\$ ${f.valor.toStringAsFixed(2)}', style: pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 8),
            pw.Text('Forma de pagamento: ${f.formaPagamento}', style: pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 8),
            pw.Text('Vencimento: ${f.vencimento}', style: pw.TextStyle(fontSize: 12)),
            pw.SizedBox(height: 8),
            pw.Text('Data do recebimento: $dataPagamento', style: pw.TextStyle(fontSize: 12)),
            if (f.retorno.isNotEmpty) ...[
              pw.SizedBox(height: 8),
              pw.Text('Retorno: ${f.retorno}', style: pw.TextStyle(fontSize: 12)),
            ],
            pw.SizedBox(height: 28),
            pw.Text('Status: RECEBIDO', style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 40),
            pw.Center(child: pw.Text('Obrigado pela preferência.')),
          ],
        ),
      ),
    ),
  );

  await Printing.layoutPdf(onLayout: (format) async => doc.save());
}

void main() async { WidgetsFlutterBinding.ensureInitialized(); await openVigDb(); runApp(const App()); }

class App extends StatefulWidget { const App({super.key}); @override State<App> createState()=>_AppState(); }
class _AppState extends State<App> { bool dark=true; @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'VIG Security',theme:ThemeData(brightness:dark?Brightness.dark:Brightness.light,colorScheme:ColorScheme.fromSeed(seedColor:yellow,brightness:dark?Brightness.dark:Brightness.light),scaffoldBackgroundColor:dark?darkBg:const Color(0xfff4f4f4),useMaterial3:true),home:Home(dark:dark,onTheme:(v)=>setState(()=>dark=v))); }

class Home extends StatefulWidget {
  final bool dark;
  final ValueChanged<bool> onTheme;
  const Home({super.key, required this.dark, required this.onTheme});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;

  void refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      Faturas(onChanged: refresh),
      Moradores(onChanged: refresh),
      Relatorio(onChanged: refresh),
      Config(dark: widget.dark, onTheme: widget.onTheme),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('VIG Security', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Faturas'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Moradores'),
          NavigationDestination(icon: Icon(Icons.assessment), label: 'Relatório'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Config.'),
        ],
      ),
    );
  }
}

class Moradores extends StatefulWidget {
  final VoidCallback onChanged;
  const Moradores({super.key, required this.onChanged});
  @override
  State<Moradores> createState() => _MoradoresState();
}

class _MoradoresState extends State<Moradores> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Morador>>(
      future: DB.moradores(),
      builder: (context, snapshot) {
        final all = snapshot.data ?? <Morador>[];
        final query = q.toLowerCase();
        final list = all.where((m) {
          return m.nome.toLowerCase().contains(query) ||
              m.endereco.toLowerCase().contains(query) ||
              m.bairro.toLowerCase().contains(query);
        }).toList();

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                onChanged: (v) => setState(() => q = v),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Pesquisar morador...',
                  filled: true,
                ),
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('Nenhum morador cadastrado.'))
                  : ListView.builder(
                      itemCount: list.length,
                      itemBuilder: (context, index) {
                        final m = list[index];
                        return Card(
                          color: card,
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: yellow,
                              child: Text(
                                m.nome.isEmpty ? '?' : m.nome[0].toUpperCase(),
                                style: const TextStyle(color: Colors.black),
                              ),
                            ),
                            title: Text(m.nome, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text(
                              '${m.endereco}${m.bairro.isEmpty ? '' : ' • ${m.bairro}'}\n'
                              'R\$ ${m.valor.toStringAsFixed(2)} • dia ${m.dia} • ${m.formaPagamento}',
                            ),
                            isThreeLine: true,
                            trailing: PopupMenuButton<String>(
                              onSelected: (value) async {
                                if (value == 'editar') {
                                  await form(m);
                                } else if (value == 'apagar') {
                                  await DB.deleteMorador(m.id!);
                                }
                                widget.onChanged();
                                if (mounted) setState(() {});
                              },
                              itemBuilder: (context) => const [
                                PopupMenuItem(value: 'editar', child: Text('Editar')),
                                PopupMenuItem(value: 'apagar', child: Text('Apagar')),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => form(),
                  icon: const Icon(Icons.person_add),
                  label: const Text('NOVO MORADOR'),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> form([Morador? old]) async {
    final n = TextEditingController(text: old?.nome ?? '');
    final e = TextEditingController(text: old?.endereco ?? '');
    final b = TextEditingController(text: old?.bairro ?? '');
    final d = TextEditingController(text: '${old?.dia ?? 1}');
    final v = TextEditingController(text: old == null ? '' : old.valor.toStringAsFixed(2));
    String forma = old?.formaPagamento ?? 'Pix';

    await showDialog<void>(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setDialogState) {
            return AlertDialog(
              title: Text(old == null ? 'Novo morador' : 'Editar morador'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(controller: n, decoration: const InputDecoration(labelText: 'Nome')),
                    TextField(controller: e, decoration: const InputDecoration(labelText: 'Endereço')),
                    TextField(controller: b, decoration: const InputDecoration(labelText: 'Bairro')),
                    TextField(controller: d, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Dia da cobrança')),
                    TextField(controller: v, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Valor')),
                    DropdownButtonFormField<String>(
                      value: forma,
                      decoration: const InputDecoration(labelText: 'Forma de pagamento'),
                      items: ['Pix', 'Dinheiro', 'Cartão']
                          .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                          .toList(),
                      onChanged: (x) {
                        if (x != null) setDialogState(() => forma = x);
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
                FilledButton(
                  onPressed: () async {
                    if (n.text.trim().isEmpty || e.text.trim().isEmpty) return;
                    await DB.saveMorador(
                      Morador(
                        id: old?.id,
                        nome: n.text.trim(),
                        endereco: e.text.trim(),
                        bairro: b.text.trim(),
                        dia: int.tryParse(d.text) ?? 1,
                        valor: double.tryParse(v.text.replaceAll(',', '.')) ?? 0,
                        formaPagamento: forma,
                      ),
                    );
                    if (ctx.mounted) Navigator.pop(ctx);
                    widget.onChanged();
                    if (mounted) setState(() {});
                  },
                  child: const Text('SALVAR'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class Faturas extends StatefulWidget {
  final VoidCallback onChanged;
  const Faturas({super.key, required this.onChanged});
  @override
  State<Faturas> createState() => _FaturasState();
}

class _FaturasState extends State<Faturas> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: Future.wait<dynamic>([DB.faturas(), DB.moradores()]),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final data = snapshot.data as List<dynamic>;
        final fs = data[0] as List<Fatura>;
        final ms = data[1] as List<Morador>;
        final names = {for (final m in ms) m.id!: m.nome};

        return Column(
          children: [
            Expanded(
              child: fs.isEmpty
                  ? const Center(child: Text('Nenhuma fatura cadastrada.'))
                  : ListView.builder(
                      itemCount: fs.length,
                      itemBuilder: (context, index) {
                        final f = fs[index];
                        final received = f.status == 'RECEBIDO';
                        return Card(
                          color: card,
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          child: ListTile(
                            leading: Icon(
                              received ? Icons.check_circle : Icons.receipt,
                              color: received ? Colors.green : yellow,
                            ),
                            title: Text(
                              names[f.moradorId] ?? 'Morador',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text(
                              'Vencimento: ${f.vencimento} • R\$ ${f.valor.toStringAsFixed(2)}\n'
                              '${f.formaPagamento} • ${f.status}',
                            ),
                            isThreeLine: true,
                            trailing: PopupMenuButton<String>(
                              onSelected: (value) => action(f, value),
                              itemBuilder: (context) => [
                                if (!received)
                                  const PopupMenuItem(value: 'receber', child: Text('Receber Fatura')),
                                const PopupMenuItem(value: 'retorno', child: Text('Adicionar Retorno')),
                                const PopupMenuItem(value: 'editar', child: Text('Editar')),
                                if (received)
                                  const PopupMenuItem(value: 'recibo', child: Text('Recibo / PDF')),
                                const PopupMenuItem(value: 'apagar', child: Text('Apagar')),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => newFatura(ms),
                  icon: const Icon(Icons.add),
                  label: const Text('CRIAR FATURA'),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> action(Fatura f, String action) async {
    if (action == 'receber') {
      await DB.updateFatura(f.id, {'status': 'RECEBIDO'});
    } else if (action == 'apagar') {
      await DB.deleteFatura(f.id);
    } else if (action == 'retorno') {
      final controller = TextEditingController(text: f.retorno);
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Retorno'),
          content: TextField(controller: controller, maxLines: 3),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () async {
                await DB.updateFatura(f.id, {'retorno': controller.text});
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('SALVAR'),
            ),
          ],
        ),
      );
    } else if (action == 'editar') {
      final controller = TextEditingController(text: f.valor.toStringAsFixed(2));
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Editar fatura'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Valor'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () async {
                await DB.updateFatura(
                  f.id,
                  {'valor': double.tryParse(controller.text.replaceAll(',', '.')) ?? f.valor},
                );
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('SALVAR'),
            ),
          ],
        ),
      );
    } else if (action == 'recibo') {
      final residents = await DB.moradores();
      final resident = residents.where((m) => m.id == f.moradorId).toList();
      final name = resident.isEmpty ? 'Morador' : resident.first.nome;
      await gerarReciboPdf(context, f, name);
    }

    widget.onChanged();
    if (mounted) setState(() {});
  }

  Future<void> newFatura(List<Morador> ms) async {
    if (ms.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre um morador primeiro.')),
      );
      return;
    }

    Morador selected = ms.first;
    final value = TextEditingController(text: selected.valor.toStringAsFixed(2));
    final due = TextEditingController(text: DateFormat('dd/MM/yyyy').format(DateTime.now()));
    String forma = selected.formaPagamento;

    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Criar fatura'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<Morador>(
                  value: selected,
                  decoration: const InputDecoration(labelText: 'Morador'),
                  items: ms.map((m) => DropdownMenuItem(value: m, child: Text(m.nome))).toList(),
                  onChanged: (m) {
                    if (m == null) return;
                    setDialogState(() {
                      selected = m;
                      value.text = selected.valor.toStringAsFixed(2);
                      forma = selected.formaPagamento;
                    });
                  },
                ),
                TextField(
                  controller: value,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Valor'),
                ),
                TextField(controller: due, decoration: const InputDecoration(labelText: 'Vencimento')),
                DropdownButtonFormField<String>(
                  value: forma,
                  decoration: const InputDecoration(labelText: 'Forma de pagamento'),
                  items: ['Pix', 'Dinheiro', 'Cartão']
                      .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                      .toList(),
                  onChanged: (x) {
                    if (x != null) setDialogState(() => forma = x);
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () async {
                await DB.createFatura(
                  selected.id!,
                  double.tryParse(value.text.replaceAll(',', '.')) ?? 0,
                  due.text,
                  forma,
                );
                if (ctx.mounted) Navigator.pop(ctx);
                widget.onChanged();
                if (mounted) setState(() {});
              },
              child: const Text('CRIAR'),
            ),
          ],
        ),
      ),
    );
  }
}

class Relatorio extends StatefulWidget {
  final VoidCallback onChanged;
  const Relatorio({super.key, required this.onChanged});
  @override
  State<Relatorio> createState() => _RelatorioState();
}

class _RelatorioState extends State<Relatorio> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: Future.wait<dynamic>([DB.moradores(), DB.faturas()]),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final data = snapshot.data as List<dynamic>;
        final ms = data[0] as List<Morador>;
        final fs = data[1] as List<Fatura>;
        final query = q.toLowerCase();
        final list = ms.where((m) {
          return m.nome.toLowerCase().contains(query) ||
              m.endereco.toLowerCase().contains(query) ||
              m.bairro.toLowerCase().contains(query);
        }).toList();
        final received = fs.where((f) => f.status == 'RECEBIDO').length;

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                onChanged: (v) => setState(() => q = v),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Pesquisar todos os moradores...',
                  filled: true,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  metric('Moradores', '${ms.length}'),
                  const SizedBox(width: 8),
                  metric('Recebidas', '$received'),
                  const SizedBox(width: 8),
                  metric('Faturas', '${fs.length}'),
                ],
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('Nenhum morador encontrado.'))
                  : ListView.builder(
                      itemCount: list.length,
                      itemBuilder: (context, index) {
                        final m = list[index];
                        final mine = fs.where((f) => f.moradorId == m.id).toList();
                        final last = mine.isEmpty ? null : mine.first;
                        final ok = last?.status == 'RECEBIDO';
                        return Card(
                          color: card,
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          child: ListTile(
                            title: Text(m.nome, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text(
                              '${m.endereco}${m.bairro.isEmpty ? '' : ' • ${m.bairro}'}\n'
                              'Dia ${m.dia} • R\$ ${m.valor.toStringAsFixed(2)} • ${m.formaPagamento}\n'
                              'Status: ${last?.status ?? 'SEM FATURA'}',
                            ),
                            isThreeLine: true,
                            trailing: Icon(
                              ok ? Icons.check_circle : Icons.circle_outlined,
                              color: ok ? Colors.green : yellow,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        );
      },
    );
  }

  Widget metric(String title, String value) {
    return Expanded(
      child: Card(
        color: card,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              Text(title, style: const TextStyle(fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

class Config extends StatelessWidget {
  final bool dark;
  final ValueChanged<bool> onTheme;
  const Config({super.key, required this.dark, required this.onTheme});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          color: card,
          child: SwitchListTile(
            title: const Text('Tema escuro'),
            subtitle: const Text('Alternar aparência do aplicativo'),
            value: dark,
            onChanged: onTheme,
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.storage),
            title: Text('Banco de dados local'),
            subtitle: Text('Moradores e faturas ficam salvos no aparelho.'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.print),
            title: Text('Impressão Bluetooth'),
            subtitle: Text('Recibos podem ser enviados para a tela de impressão do aparelho.'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.picture_as_pdf),
            title: Text('Relatórios em PDF'),
            subtitle: Text('Recibos recebidos podem ser gerados em PDF.'),
          ),
        ),
      ],
    );
  }
}
