# VIG SECURITY — compilação na nuvem

Este projeto contém o código Flutter do VIG SECURITY e um workflow do GitHub Actions que cria a estrutura Android automaticamente e gera o APK de release.

## Como gerar o APK pelo celular

1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste projeto para o repositório.
3. Abra a aba **Actions**.
4. Selecione **Build VIG Security APK**.
5. Toque em **Run workflow**.
6. Quando terminar, abra a execução concluída e baixe o artefato **vig-security-apk**.
7. O arquivo dentro do artefato é `app-release.apk`.

O workflow usa Flutter stable e executa `flutter create --platforms=android` no servidor, portanto a pasta Android não precisa estar no ZIP.
