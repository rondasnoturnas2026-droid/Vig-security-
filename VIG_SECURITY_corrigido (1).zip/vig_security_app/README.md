# VIG Security

Primeira versão funcional baseada nas telas enviadas.

## Incluído
- Cadastro, edição e exclusão de moradores.
- SQLite local para manter os dados no aparelho.
- Criação de faturas vinculadas aos moradores.
- Receber fatura: status passa para RECEBIDO e é salvo.
- Editar, adicionar retorno e apagar faturas.
- Relatório com todos os moradores e busca.
- Tema escuro.

## Rodar
flutter pub get
flutter run

## APK
flutter build apk --release


## V2 - Recibos e impressão
- Faturas recebidas podem gerar um recibo em PDF.
- O recibo inclui morador, valor, forma de pagamento, vencimento, data do recebimento e retorno.
- O aplicativo abre a interface de impressão/compartilhamento do sistema.
- A integração específica com impressoras térmicas Bluetooth fica como próxima etapa.
